package com.venkat;

public class Desktop implements Computer{

    public Desktop(){
        System.out.println("object created for Desktop");
    }

    public void compile() {
        System.out.println("compiling for Desktop");
    }
}
