package com.venkat;

public interface Computer {
    void compile();
}
