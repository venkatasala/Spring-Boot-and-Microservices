package com.venkat.jbased;

import com.venkat.Desktop;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class Appconfig {
    //@Bean({"com"})
    @Bean
    @Scope(value = "prototype")
    public Desktop desktop(){
        return new Desktop();
    }

}
