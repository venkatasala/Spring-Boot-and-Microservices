insert into user_details(id,birth_date,name)
values(10001,current_date(),'venkat');

insert into user_details(id,birth_date,name)
values(10002,current_date(),'shyam');

insert into user_details(id,birth_date,name)
values(10003,current_date(),'virat');