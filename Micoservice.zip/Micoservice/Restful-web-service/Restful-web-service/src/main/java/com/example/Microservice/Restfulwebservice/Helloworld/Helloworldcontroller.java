package com.example.Microservice.Restfulwebservice.Helloworld;

import com.example.Microservice.Restfulwebservice.HelloworldBean.HelloworldBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Helloworldcontroller {
    @GetMapping(path = "/hello-world")
    //@RequestMapping(method = RequestMethod.GET,path="/hello-world")
    public String Helloworld(){

        return "Hello world";
    }

    //Bean is used for formating to JSON format
    @GetMapping(path="/hello-world-bean")
    public HelloworldBean helloworldBean(){
        return new HelloworldBean("Hello world Bean");
    }

    //path parameters
    // /users/{id}/todos/{id}=> /users/2/todos/200
    // /hello-world-path-variable/{name}
    // /hellow-world/path-variable/venkat
    @GetMapping(path="/hello-world/path-variable/{name}")
    public HelloworldBean helloworldPathVariable(@PathVariable String name){
        return new HelloworldBean("Hello world path:" +" "+  name);
    }

}

