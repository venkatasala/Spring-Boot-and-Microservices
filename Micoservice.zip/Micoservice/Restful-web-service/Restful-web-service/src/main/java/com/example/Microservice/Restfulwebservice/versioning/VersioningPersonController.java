package com.example.Microservice.Restfulwebservice.versioning;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class VersioningPersonController {
    @GetMapping("/v1/person")
    public Personv1 getFirstversionofperson(){
        return new Personv1("Bob Charlie");
    }
    @GetMapping("/v2/person")
    public Personv2 getSecondversionofperson(){
        return new Personv2(new Name("bob","charlie"));
    }
    @GetMapping(path ="/person", params = "version=1")
    public Personv1 getFirstversionofpersonRequestParameter(){
        return new Personv1("bob charlie");
    }
    @GetMapping(path = "/person", params = "version=2")
    public Personv2 getSecondversionofpersonRequestparameter(){
        return new Personv2(new Name("bob","charlie"));
    }
    @GetMapping(path ="/person/header", headers = "X-API-VERSION=1")
    public Personv1 getFirstversionofpersonRequestHeader(){
        return new Personv1("bob charlie");
    }
    @GetMapping(path = "/person", headers = "X-API-VERSION=2")
    public Personv2 getSecondversionofpersonRequestheader(){
        return new Personv2(new Name("bob","charlie"));
    }
    @GetMapping(path ="/person/accept", produces = "application/vnd.copany.app-vi+json")
    public Personv1 getFirstversionofpersonAcceptHeader(){
        return new Personv1("bob charlie");
    }
//    @GetMapping(path = "/person/accept", produces = "application/vnd.copany.app-vi+json")
//    public Personv2 getSecondversionofpersonAccpetheader(){
//        return new Personv2(new Name("bob","charlie"));
//    }
}
