package com.example.Microservice.Restfulwebservice.jpa;

import com.example.Microservice.Restfulwebservice.User.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Integer> {

}
