package com.example.Microservice.Restfulwebservice.HelloworldBean;


//Json Format
public class HelloworldBean {
    public String message;
    public HelloworldBean(String message) {
        this.message=message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "HelloworldBean{" +
                "message='" + message + '\'' +
                '}';
    }
}
