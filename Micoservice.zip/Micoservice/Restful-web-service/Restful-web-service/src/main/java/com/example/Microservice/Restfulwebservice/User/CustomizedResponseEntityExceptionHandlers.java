package com.example.Microservice.Restfulwebservice.User;

import org.springframework.context.MessageSourceAware;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

public interface CustomizedResponseEntityExceptionHandlers extends MessageSourceAware {
    @ExceptionHandler(Exception.class)
    ResponseEntity<ErrorDetails> handleAllException(Exception ex, WebRequest request);

    @ExceptionHandler(UserNotFoundException.class)
    ResponseEntity<ErrorDetails> handleUserNotFoundException(Exception ex, WebRequest request);

    ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpStatus headers, HttpStatusCode status, WebRequest request);
}
