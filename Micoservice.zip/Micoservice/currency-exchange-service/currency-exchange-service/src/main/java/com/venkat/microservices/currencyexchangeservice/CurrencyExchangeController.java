package com.venkat.microservices.currencyexchangeservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@RestController
public class CurrencyExchangeController {
    @Autowired
    private CurrencyExchangeRepository repository;
    @Autowired
    private Environment environment;
    @GetMapping("/currency-exchange/from/{from}/to/{to}")
    public CurrencyExchnage retriveExchangeValue(@PathVariable String from,
                                                 @PathVariable String to){
        //CurrencyExchnage currencyExchnage=new CurrencyExchnage(1000L,from,to, BigDecimal.valueOf(50));
        CurrencyExchnage currencyExchnage=repository.findByFromAndTo(from,to);
        if(currencyExchnage==null){
            throw new RuntimeException("Unable to find data for " +from+"to"+to);

        }
        String port=environment.getProperty("local.server.port");
        currencyExchnage.setEnvironment(port);

        return currencyExchnage;
    }
}

