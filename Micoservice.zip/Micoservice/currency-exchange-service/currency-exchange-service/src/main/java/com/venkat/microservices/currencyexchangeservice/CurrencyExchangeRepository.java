package com.venkat.microservices.currencyexchangeservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CurrencyExchangeRepository extends JpaRepository<CurrencyExchnage, Long> {
    CurrencyExchnage findByFromAndTo(String from, String to);
}
