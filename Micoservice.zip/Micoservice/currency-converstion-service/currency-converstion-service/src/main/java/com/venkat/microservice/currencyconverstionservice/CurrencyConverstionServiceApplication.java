package com.venkat.microservice.currencyconverstionservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyConverstionServiceApplication {

	public static void main(String[] args) {

		SpringApplication.run(CurrencyConverstionServiceApplication.class, args);
		System.out.println("venkat");
	}

}
